This LUT.png file was made by @eswnl, all credits go to him.
It was taken from this repository, with permission and converted to PNG.

https://github.com/eswnl/FY-2x_CLUT